from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth import logout
from django.urls import reverse
from .forms import  SignUpForm
import logging
from django.contrib.auth import login as auth_login_user
from django.core.mail import send_mail
from django.conf import settings
from farmersapp.models import Users

import logging
logging.basicConfig(filename='logfile.log', level=logging.INFO)
logger = logging.getLogger(__name__)






# def login_view(request):
#     if request.method == 'POST':
#         logger.info("Login view is called.")
#         username = request.POST.get('username')
#         password = request.POST.get('password')
#         user = authenticate(request, username=username, password=password)
#         logger.info(user)
#         if user is not None:
#             logger.info("User is authenticated.")
#             return redirect(reverse('profile:home'))
#         else:
#             logger.error("User is not authenticated.15")
#             messages.error(request, 'Invalid username or password.')
#     else:
#         logger.info("d.2 else get request.")

#     return render(request, 'registration/login.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        # logger.info(f"Attempt to login with username: {username}")

        if user is not None:
            login(request, user)
            # logger.info(f"User {username} authenticated successfully.")
            return redirect(reverse('profile:home'))
        else:
            # logger.warning(f"Failed login attempt for username: {username}")
            messages.error(request, 'Invalid username or password.')
            return redirect(reverse('login'))  # Redirect back to login page to clear form

    return render(request, 'registration/login.html')

def logout_view(request):
    logout(request)
    messages.success(request, 'You have been logged out.')

    return redirect('login')  
                                   
def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'registration/signup.html', {'form': form})