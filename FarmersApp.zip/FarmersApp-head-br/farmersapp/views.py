from django.shortcuts import render, redirect, get_object_or_404
from .forms import UserForm, CategoryForm, IncomeForm, ExpenseForm, AreaForm, LivestockForm, FinanceForm, EquipmentForm, CityForm
import logging
from .models import Users, Category, Income, Expense, Area, Livestock, Equipment, Finance
import requests
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.db.models import Sum, Case, When, Value 
from django.db import models


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
log_file = logging.FileHandler('logfile.log')
logger.addHandler(log_file)


@login_required
def init(request):
    return render(request, 'farmersapp/login.html')


@login_required 
def home(request):
    return render(request, 'farmersapp/index.html',
                  {"icon": Update_weather.icon, 
                   'summary': Update_weather.precipitation, 
                  'temperature': Update_weather.temperature,
                  'name': Update_weather.name,
                  'precipitation': Update_weather.precipitation,
                  })


@login_required
def get_users(request):
    # logger.info('Getting all users started')
    if request.method == 'GET':
        all_users = Users.objects.all()
        return render(request, 'farmersapp/users.html', {'users': all_users})
    
@login_required
def register(request):
    # logger.info('Creating a new user started')
    if request.method == "POST":
        # logger.info('Creating a new user if block started')
        form = UserForm(request.POST)
        if form.is_valid():
            logger.info('User Form is valid')
            form.save()
            return redirect('profile:login')
    else:
        # logger.info('Creating a new user else block started')
        form = UserForm()
     
    all_users = Users.objects.all()
    return render(request, 'farmersapp/users.html', {'form': form, 'users': enumerate(all_users)})


#################### Areas ####################
@login_required
def my_areas(request):
    # logger.info('Getting areas for current user started')
    if request.method == 'GET':
        current_user_areas = Area.objects.filter(user=request.user)
        return render(request, 'farmersapp/areas/my_areas.html', {'areas': current_user_areas})
    else:
        form = AreaForm()
        return render(request, 'farmersapp/areas/area_form.html', {'form': form})


@login_required
def create_area(request):
    form = AreaForm(request.POST or None)
    form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    if request.method == 'POST' and form.is_valid():
        area = form.save(commit=False)
        area.user = request.user 
        area.save()
        form.save_m2m()
        messages.success(request, 'Fields added successfully')
        return redirect('profile:my_areas')
    return render(request, 'farmersapp/areas/area_form.html', {'form': form})



@login_required
def area_edit(request, id):
    area = Area.objects.get(id=id)
    form = AreaForm(instance=area)
    form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    if request.method == 'POST':
        form = AreaForm(request.POST, instance=area)
        if form.is_valid():
            form.save()
            return redirect('profile:my_areas')

    return render(request, 'farmersapp/areas/edit_area.html', {'form': form})

def delete_area(request, id):
    area = Area.objects.get(id=id)
    if request.method == 'POST':
        area.delete()
        return redirect('profile:my_areas')
    return render(request, 'farmersapp/areas/my_areas.html', {'area': area})



#################### Categories ####################
@login_required
def categories(request):
    form = CategoryForm()
    if request.method == 'GET':
        user_data = Category.objects.filter(user=request.user)
        return render(request, 'farmersapp/category/categories.html', {'categories': user_data})
    return render(request, 'farmersapp/category/category_form.html', {'form': form})

@login_required
def cat_data(request, id):
    form = CategoryForm()
    if request.method == 'GET':
        user_data = Category.objects.filter(user=request.user, id=id)
        category = get_object_or_404(Category, id=id, user=request.user)

        fields = Area.objects.filter(categories=category)
        context = {
            'category': category,
            'categories': user_data,
            'fields': Area.objects.filter(categories__in=user_data),
            'equipment': Equipment.objects.filter(categories__in=user_data),
            'finance': Finance.objects.filter(categories__in=user_data),
            'fields': fields
        }
        return render(request, 'farmersapp/category/data.html', context=context)

    return render(request, 'farmersapp/category/category_form.html', {'form': form})

@login_required
def create_category(request):
    next_url = request.POST.get('next', request.GET.get('next', 'profile:categories'))
    form = CategoryForm(request.POST or None)
    form.fields['parent_category'].queryset = Category.objects.filter(user=request.user)
    if request.method == 'POST' and form.is_valid():
        category = form.save(commit=False)
        category.user = request.user
        category.save()
        form.save_m2m()
        return redirect(next_url)
    return render(request, 'farmersapp/category/category_form.html', {'form': form, 'next_url': next_url})



@login_required
def edit_category(request, id):
    category = Category.objects.get(id=id)
    form = CategoryForm(instance=category)  
    form.fields['parent_category'].queryset = Category.objects.filter(user=request.user)

    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('profile:categories')
    return render(request, 'farmersapp/category/edit_cat.html', {'form': form})

def delete_category(request, id):
    category = Category.objects.get(id=id)
    if request.method == 'POST':
        category.delete()
        return redirect('profile:categories')
    return render(request, 'farmersapp/category/categories.html', {'category': category})


#################### Equipments ####################
@login_required
def equipments(request):
    if request.method == 'GET':
        user_equipments = Equipment.objects.filter(user=request.user)
        return render(request, 'farmersapp/equipment/equipment.html', {'equipments': user_equipments})
    else:
        form = EquipmentForm()
    return render(request, 'farmersapp/equipment/equipment.html', {'form': form})


@login_required
def create_equipment(request):
    # https://openweathermap.org/api/geocoding-api
    if request.method == 'POST':
        form = EquipmentForm(request.POST)
        if form.is_valid():
            equipment = form.save(commit=False)
            equipment.user = request.user
            equipment.save()
            form.save_m2m()
            messages.success(request, 'category created successfully')
            return redirect('profile:equipment')
    else:
        form = EquipmentForm()
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/equipment/equipment_form.html', {'form': form})
    
@login_required
def edit_equipment(request, id):
    equipment = Equipment.objects.get(id=id)
    if request.method == 'POST':
        form = EquipmentForm(request.POST, instance=equipment)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile:equipment')
    else:
        form = EquipmentForm(instance=equipment)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/equipment/edit_equipment.html', {'form': form})

def delete_equipment(request, id):
    equipment = Equipment.objects.get(id=id)
    if request.method == 'POST':
        equipment.delete()
        return redirect('profile:equipment')
    return render(request, 'farmersapp/equipment/equipments.html', {'equipment': equipment})

#################### Finance ####################

@login_required
def finance(request):
    if request.method == "GET":
        user_info = Finance.objects.filter(user=request.user)
        balances = user_info.aggregate(
            total_income=Sum(Case(
                When(type='income', then='amount'),
                default=Value(0),
                output_field=models.DecimalField()
            )),
            total_expense=Sum(Case(
                When(type='expense', then='amount'),
                default=Value(0),
                output_field=models.DecimalField()
            ))
            )        
        total_income = balances.get('total_income', 0) or 0
        total_expense = balances.get('total_expense', 0) or 0
        balance = total_income - total_expense

        context = {
            'data': user_info,
            'balance': balance
        }
        return render(request, 'farmersapp/inex/finance.html', context)
    else:
        form = FinanceForm()
    return render(request, 'farmersapp/inex/finance.html', {'form': form })


@login_required
def add_inex(request):
    if request.method == 'POST':
        form = FinanceForm(request.POST)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():            
            inex = form.save(commit=False)
            inex.user = request.user
            inex.save()
            form.save_m2m()
            messages.success(request, f'{form.fields['type']} added successfully')
            next_url = request.POST.get('next', '/')
            if next_url:
                return HttpResponseRedirect(next_url)
            else:
                return redirect('profile:finance')
    else:
        form = FinanceForm()
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/inex/in_form.html', {'form': form})

def edit_inex(request, id):    
    inex = Finance.objects.get(id=id)
    if request.method == 'POST':
        form = FinanceForm(request.POST, instance=inex)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile:finance')
    else:
        form = FinanceForm(instance=inex)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/inex/edit_income.html', {'form': form})

def delete_inex(request, id):
    inex = Finance.objects.get(id=id)
    if request.method == 'POST':
        inex.delete()
        return redirect('profile:finance')
    return render(request, 'farmersapp/inex/finance.html', {'income': inex})

#################### Incomes #####################
@login_required
def income(request):
    if request.method == 'GET':
        user_incomes = Income.objects.filter(user=request.user)
        return render(request, 'farmersapp/inex/income.html', {'incomes': user_incomes})
    else:
        form = IncomeForm()
    return render(request, 'farmersapp/inex/income.html', {'form': form})

@login_required
def create_income(request):
    if request.method == 'POST':
        form = IncomeForm(request.POST)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():
            income = form.save(commit=False)
            income.user = request.user
            income.save()
            form.save_m2m()
            messages.success(request, 'Fields added successfully')
            next_url = request.POST.get('next', '/')
            if next_url: 
                return HttpResponseRedirect(next_url)  
            else:
                return redirect('profile:income')
    else:
        form = IncomeForm()
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/inex/in_form.html', {'form': form})

@login_required
def edit_income(request, id):
    income = Income.objects.get(id=id)
    if request.method == 'POST':
        form = IncomeForm(request.POST, instance=income)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile:income')
    else:
        form = IncomeForm(instance=income)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/inex/edit_income.html', {'form': form})

def delete_income(request, id):
    income = Income.objects.get(id=id)
    if request.method == 'POST':
        income.delete()
        return redirect('profile:income')
    return render(request, 'farmersapp/income/income.html', {'income': income})



#################### Expenses ####################
@login_required
def expense(request):
    if request.method == 'GET':
        user_expenses = Expense.objects.filter(user=request.user)
        return render(request, 'farmersapp/inex/expense.html', {'expenses': user_expenses})
    else:
        form = ExpenseForm()
    return render(request, 'farmersapp/inex/expense.html', {'form': form})


@login_required
def create_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            form.save_m2m()
            messages.success(request, 'Fields added successfully')
            next_url = request.POST.get('next', '/')
            if next_url: 
                return HttpResponseRedirect(next_url)  
            else:   
                return redirect('profile:expense')
    else:
        form = ExpenseForm()
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/inex/in_form.html', {'form': form})

@login_required
def edit_expense(request, id):  
    expense = Expense.objects.get(id=id)
    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile:expense')
    else:
        form = ExpenseForm(instance=expense)
    return render(request, 'farmersapp/inex/edit_income.html', {'form': form})
    
def delete_expense(request, id):
    expense = Expense.objects.get(id=id)
    if request.method == 'POST':
        expense.delete()
        return redirect('profile:expense')
    return render(request, 'farmersapp/inex/expense.html', {'expense': expense})

#################### Livestock ####################
@login_required
def livestock(request):
    if request.method == 'GET':
        user_livestock = Livestock.objects.filter(user=request.user)
        return render(request, 'farmersapp/livestock/livestock.html', {'livestock': user_livestock})
    else:
        form = LivestockForm()
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        
    return render(request, 'farmersapp/livestock/livestock.html', {'form': form})

@login_required
def create_livestock(request):
    if request.method == 'POST':
        form = LivestockForm(request.POST)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():
            lvst = form.save(commit=False)
            lvst.user = request.user
            lvst.save()
            form.save_m2m()
            next_url = request.GET.get('next', None)
            if next_url:
                return redirect(next_url)   
            else:
                return redirect('profile:livestock')
    else:
        form = LivestockForm()
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/livestock/livestock_form.html', {'form': form})

@login_required
def edit_livestock(request, id):
    livestock = Livestock.objects.get(id=id)
    if request.method == 'POST':
        form = LivestockForm(request.POST, instance=livestock)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
        if form.is_valid():
            lvst = form.save(commit=False)
            lvst.user = request.user
            lvst.save()
            form.save_m2m()
            return redirect('profile:livestock')
    else:
        form = LivestockForm(instance=livestock)
        form.fields['categories'].queryset = Category.objects.filter(user=request.user)
    return render(request, 'farmersapp/livestock/edit_livestock.html', {'form': form})
    
def delete_livestock(request, id):
    livestock = Livestock.objects.get(id=id)
    if request.method == 'POST':
        livestock.delete()
        return redirect('profile:livestock')
    return render(request, 'farmersapp/livestock/livestock.html', {'livestock': livestock})






#################### Weather ####################
def get_lat_lng(city_name):
    # https://openweathermap.org/api/geocoding-api
    API_KEY = 'cab5bb60507cace9c1291861909cf334'
    limit = 1
    response = requests.get(f'http://api.openweathermap.org/geo/1.0/direct?q={city_name}&limit={limit}&appid={API_KEY}')
    data = response.json()
    return data[0]['lon'], data[0]['lat'], data[0]['name']

def city(request):
    form = CityForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            city = form.cleaned_data['city']
            form.save()
            return city
    return render(request, 'farmersapp/city_update.html', {'form': form})

    


class Update_weather:
    API_KEY = 'b5fc99d5de9b9472ce9bd0f9a7a533db'
    city = "Moscow"
    lat, lon, name =  get_lat_lng(city)
    lang = 'en'
    
    response = requests.get(f'https://api.openweathermap.org/data/3.0/onecall?lat={lat}&lon={lon}&appid={API_KEY}&lang={lang}')
    data = response.json()
    summary = data["daily"][-1]['summary']
    temperature = round(data['current']['temp'] - 273.15, 1)
    icon = data['current']['weather'][0]['icon']
    precipitation = data['current']['weather'][0]['description']
    name = name


